Teaching Template

- Use this template for new classes
- Contains separate folders for materials, assessments, administration
- As you go, edit this file to describe the class
- Make sure it has information about where/when it was taught
- Syllabus goes in here IF IT IS SHORT
- Syllabus goes in syllabus.docx in this folder IF IT IS LONG

